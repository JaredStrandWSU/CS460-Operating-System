#include "ucode.c"

int tokenizeString(char *line, char *tokens[], char delimiter)
{
  char *cp = line;
  int index = 0;
  /// Taken from 'token()' in crt0.c
  while (*cp != 0)
  {
    /// Trims whitespace
    while (*cp == ' ')
      *cp++ = 0;
    /// Scans string
    if (*cp != 0)
      tokens[index++] = cp;
    /// Splits lines
    while (*cp != delimiter && *cp != 0)
      cp++;
    if (*cp != 0)
      *cp = 0;
    else
      break;
    cp++;
  }
  return index;
}

int main(int argc, char *argv[ ])
{
/*
(3). then (in sh) it loops forever (until "logout"):
      {
          prompts for a command line, e.g. cmdLine="cat filename"
          if (cmd == "logout") 
            syscall to die;

          // if just ONE cmd:  
          pid = fork();
          if (pid==0)
              exec(cmdLine);
          else
              pid = wait(&status);
      } 
*/
  char cmdLine[128];
  char *inputArr[128];
  int inputTokens = 0, i = 0;
  prints("\n      *** WELCOME TO J-UNIX SHELL ***      \n");
  while(1)
  {
    prints("#sh: ");
    gets(cmdLine); prints("\n");
    if (cmdLine[0] == 0)
      continue;
    inputTokens = tokenizeString(cmdLine, inputArr, ' ');

    printf("cmd: %s\n", inputArr[0]);
    for(i=0; i < (inputTokens - 1); i++)
    {
      printf("arg[%d]: %s", i, inputArr[i+1]);
    }
    
    prints("\nDo a cool command!\n");
    //exec("ls");
    prints("\n      *** EXITING J-UNIX SHELL ***      \n");
    exit(0); //exit back to login terminal
  }
}